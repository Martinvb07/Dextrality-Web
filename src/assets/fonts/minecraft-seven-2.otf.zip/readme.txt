﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “Baldionlyfont”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/2671731

*NOTE: “Minecraft Seven 2” was originally cloned (copied) from the
FontStruction “Minecraft Seven”
(https://fontstruct.com/fontstructions/show/2671728) by “Baldionlyfont”,
which is licensed under a Creative Commons Attribution license
(http://creativecommons.org/licenses/by/3.0/).
“Minecraft Seven” was in turn cloned (copied) from the FontStruction
“Mojangle” (https://fontstruct.com/fontstructions/show/2578151) by
“Baldionlyfont”, which is licensed under a Creative Commons Attribution
license (http://creativecommons.org/licenses/by/3.0/).
“Mojangle” was in turn cloned (copied) from the FontStruction “Minecraftia
2.0” (https://fontstruct.com/fontstructions/show/2511594) by
“Baldionlyfont”, which is licensed under a Creative Commons Attribution
license (http://creativecommons.org/licenses/by/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2025 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
